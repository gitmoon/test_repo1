#!/bin/sh

app=hardware_manager
application_PID=`ps -ax | grep $app | grep -v grep | awk {'print $1'}`

if [ -z "$application_PID" ]
then
	echo "application $app is not running"
        exit 1
else
	echo "pid of application is $application_PID"
	echo "try to stop $app ..."
	systemctl stop $app
fi

WAIT_SECONDS=10
count=0

application_PID=`ps -ax | grep $app | grep -v grep | awk {'print $1'}`
# kill application
if [ -z "$application_PID" ]
then
	echo "application $app is stopped"
else
	while kill $application_PID 2> /dev/null;
	do
		sleep 1
		((count++))

		if ! ps -p $application_PID ; then
			break
		fi


		if [ $count -gt $WAIT_SECONDS ]; then
			kill -9 $application_PID
			break
		fi

	done
fi
